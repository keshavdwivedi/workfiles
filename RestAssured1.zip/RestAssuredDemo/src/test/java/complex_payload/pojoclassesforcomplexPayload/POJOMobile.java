package complex_payload.pojoclassesforcomplexPayload;

public class POJOMobile {

    public POJOMobile(int number, int id) {
        this.number = number;
        this.id = id;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    private int number;
    private int id;


}
